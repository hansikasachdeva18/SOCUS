<?php  
date_default_timezone_set("Asia/Kolkata");  
 
require __DIR__ . '/includes/config.php';  
?> 
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Questions</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="tinymce/tinymce.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="assets/css/style_home_1.css">

    <style>
        * {
          box-sizing: border-box;
        }

        /* Create two unequal columns that floats next to each other */
        .column {
          float: left;
          padding-left: 8px;
          padding-right: 8px;
          padding-top: 10px;
          padding-bottom: 60px;
          width: 100%;
          margin-bottom: 0;
        }

        .left {
          width: 40%;
        }

        .right {
          width: 60%;
        }

        /* Clear floats after the columns */
        .row:after {
          content: "";
          display: table;
          clear: both;
        }

        /* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
        @media screen and (max-width: 600px) {
          .column {
            width: 100%;
          }
        }

        div.leftH2{
          margin-left: 5px;
          padding-left: 5px;
          text-align:justify;
          word-wrap: break-word;
        }
        div.rightH2{
          margin-left: 5px;
          padding-left: 5px;
          font-size: 22px;
          color: black;
          font-family: Georgia, Garamond, serif;
        }
        .img-responsive{
            display: block; max-width: 100%; height: auto; border-radius: 25px; padding: 5px;
        }
    </style>
    <script>
         tinymce.init({
           selector: 'textarea#question',  //Change this value according to your HTML
           auto_focus: 'question',
           width: "700",
           height: "200"
         }); 
 
    </script>
    <script>
         tinymce.init({
           selector: 'textarea#notes',  //Change this value according to your HTML
           auto_focus: 'notes',
           width: "700",
           height: "200"
         });

    </script>
</head>

<body>
    <!-- Debut du code de la barre de navigation -->
   <!-- <header>
        <nav class="navbar">
            <a href="#" class="navbar__logo">SOCUS</a>
            <ul>
                <li><a href="homepage.php">Home</a></li>
                <li><a href="toplearners.php">Top Learners</a></li>
                <li><a href="schedules.php">Schedules</a></li>
                <li><a href="">Profile</a></li>
                <li class="cta__button"><a href="logout.php">Logout</a></li>
            </ul>
            <button class="navbar__toggler">
                <span></span>
            </button>
        </nav>
    </header>
-->
    <div class="team-boxed">
            
                <h2 class="text-center">Add New Question</h2>
            
            <div class="row" style="margin: auto">
              <div class="column left">
                <div class="box"><img class="img-responsive" src="assets/img/que.png">
                </div>
              </div>
              <div class="column right">
                <form action="" method="post">

                        <div class="rightH2">
                            Parent Topic Name
                        </div>
                        <div class="form-group shadow-textarea">
                          <select name="parent_topic_name" id="parent_topic_name" required="required">
                              <option value="Data Structures & Algorithms">Data Structures & Algorithms</option>
                              <option value="Machine Learning With Python">Machine Learning With Python</option>
                          </select>
                        </div>

                        <div class="rightH2">
                            Sub Topic Name
                        </div>
                        <div class="form-group shadow-textarea">
                          <input class="form-control z-depth-1" id="sub_topic_name" name="sub_topic_name" required="required">  
                          </input>
                        </div>

                        <div class="rightH2">
                            Difficulty Level
                        </div>
                        <div class="form-group shadow-textarea">
                          <select name="difficulty_level" id="difficulty_level" required="required">
                              <option value="1">Beginner</option>
                              <option value="2">Intermediate</option>
                              <option value="3">Advance</option>
                          </select>
                        </div>

                        <div class="rightH2">
                            Question Title
                        </div>
                        <div class="form-group shadow-textarea">
                          <input class="form-control z-depth-1" id="question_title" name="question_title" required="required">  
                          </input>
                        </div>

                        <div class="rightH2">
                           Type Question Here
                        </div>
                        <div class="form-group shadow-textarea">
                          <textarea name="question" id="question"></textarea>
                        </div>

                        <div class="rightH2">
                           Type Notes Here
                        </div>
                        <div class="form-group shadow-textarea">
                          <textarea name="notes" id="notes"></textarea>
                        </div>
                        
                        <div class="rightH2">
                        <div><button class="button-3" role="button" value=" Submit " name="submit" id="submit">Submit</button></div>
                        </div>
                   
                </form>
              </div>
            </div>
    </div>

    <?php
    if(isset($_POST["submit"])){

        try {
        $db = DataBase();
            $sql = "INSERT INTO coding_questions(parent_topic_name, sub_topic_name, difficulty_level, question_title, question, notes) VALUES (:parent_topic_name,:sub_topic_name,:difficulty_level,:question_title,:question, :notes)";
              $query = $db->prepare($sql);
              $query->bindParam("parent_topic_name", $_POST['parent_topic_name'], PDO::PARAM_STR);
              $query->bindParam("sub_topic_name", $_POST['sub_topic_name'] , PDO::PARAM_STR);
              $query->bindParam("difficulty_level", $_POST['difficulty_level'], PDO::PARAM_STR);
              $query->bindParam("question_title", $_POST['question_title'], PDO::PARAM_STR);
              $query->bindParam("question", trim($_POST['question']), PDO::PARAM_STR);
              $query->bindParam("notes", trim($_POST['notes']), PDO::PARAM_STR);
              $query->execute();
              $lastinserid = $db->lastInsertId();
              if ($lastinserid>0) {
                echo '<script type="text/javascript">
                        setTimeout(function() {
                            swal({
                        title: "Success",
                        text: "Question Added Successfully.",
                        icon: "success"
                        }).then(function() {
                            window.top.location = window.top.location;
                        });
                        }, 1000);
                        </script>';
        }
        else{
        echo '<script type="text/javascript">
                                    setTimeout(function() {
                                        swal({
                                    title: "Ooppssss",
                                    text: "Something went wrong, please try again!",
                                    icon: "error"
                                    }).then(function() {
                                        window.location = "homepage.php";
                                    });
                                    }, 1000);
                                    </script>';
        }

        $dbh = null;
        }
        catch(PDOException $e)
        {
        echo $e->getMessage();
        }

    }
    ?>

    <script src="assets/js/nav-bar.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
</body>

</html>