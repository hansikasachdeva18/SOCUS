# User-Account-Sign-up-and-Sign-in
The form templates was forked from 
https://github.com/sefyudem/Sliding-Sign-In-Sign-Up-Form

#screenshots

![Signin](screenshots/login.png?raw=true "Signin page")
![Signup](screenshots/signup.png?raw=true "Signup page")

# Installation

1. Clone the repository

2. create database 'user_accounts'.you can change this in the config.php inside includes folder

3. import the sql file in the Database folder

 http://localhost/User-Account-Sign-up-and-Sign-in

4. Congratulations
